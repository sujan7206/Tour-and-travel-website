document.addEventListener('DOMContentLoaded', () => {
    const taglines = ['Explore new places', 'Discover new adventure', 'Travel your dream places'];
    let index = 0;
    setInterval(() => {
        document.getElementById('tagline').textContent = taglines[index];
        index = (index + 1) % taglines.length;
    }, 3000);
});